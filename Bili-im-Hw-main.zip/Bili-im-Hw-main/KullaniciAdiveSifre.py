# Kullanıcıdan kullanıcı adı ve şifreyi al
kullanici_adi = input("Kullanıcı adınızı girin: ")
sifre = input("Şifrenizi girin: ")

# Kullanıcı adı ve şifreyi ekrana yazdır
print(f"Kullanıcı adı: {kullanici_adi}")
print(f"Şifre: {sifre}")

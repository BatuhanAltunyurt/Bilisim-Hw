# Kullanıcıdan kenar uzunluklarını al
kenar1 = float(input("Dikdörtgenin birinci kenar uzunluğunu girin: "))
kenar2 = float(input("Dikdörtgenin ikinci kenar uzunluğunu girin: "))

# Dikdörtgenin çevresini hesapla
cevre = 2 * (kenar1 + kenar2)

# Sonucu ekrana yazdır
print(f"Dikdörtgenin çevresi: {cevre}")

# Kullanıcıdan sayıyı al
sayi = float(input("Bir sayı girin: "))

# Sayının karesini hesapla
kare = sayi ** 2

# Sonucu ekrana yazdır
print(f"Girdiğiniz sayının karesi: {kare}")

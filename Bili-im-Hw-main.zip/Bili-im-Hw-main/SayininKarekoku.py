import math

# Kullanıcıdan sayıyı al
sayi = float(input("Bir sayı girin: "))

# Sayının karekökünü hesapla (Karekök'ü hesaplamak için sadece math kütüphanesini biliyorum.)
kok = math.sqrt(sayi)

# Sonucu ekrana yazdır
print(f"Girdiğiniz sayının karekökü: {kok}")

# Kullanıcıdan kenar uzunluğunu al
kenar = float(input("Küpün bir kenar uzunluğunu girin: "))

# Küpün hacmini hesapla
hacim = kenar ** 3

# Sonucu ekrana yazdır
print(f"Küpün hacmi: {hacim}")

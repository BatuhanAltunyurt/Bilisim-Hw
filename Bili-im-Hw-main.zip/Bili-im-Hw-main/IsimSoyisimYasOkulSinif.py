# Kullanıcıdan bilgileri al
isim = input("İsminizi girin: ")
soyisim = input("Soyisminizi girin: ")
yas = input("Yaşınızı girin: ")
okul = input("Okulunuzu girin: ")
sinif = input("Sınıfınızı girin: ")

# Bilgileri yan yana yazdır
print(f"{isim} {soyisim}, {yas} yaşında, {okul} okulunda ve {sinif} sınıfındadır.")
